<footer class="footer-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-sm-6 col-md-5">
                    <div class="single-footer-widget">
                        
                        <img src="<?= base_url() ?>assets/depen/thema/logo.png" width="20%" alt="">
                        <p style="text-align: justify;  text-justify: inter-word;">Labuhan Burung adalah sebuah desa pesisir yang ada di Pulau Sumbawa. Desa ini masuk dalam wilayah Kecamatan Buer, Kabupaten Sumbawa. Desa Labuhan Burung telah di perkenalkan ke masyarakat sebagai desa wisata dengan konsep Rural Community Based Tourism ( Pariwisata Berbasis Masyarakat Pedesaan) oleh Askar DG KAMIS sejak tahun 2017
.</p> 

                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="single-footer-widget">
                        <h4>Subscribe Newsletter</h4>
                        <div class="form-wrap" id="mc_embed_signup">
                            <form target="_blank"
                                action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                                method="get" class="form-inline">
                                <input class="form-control" name="EMAIL" placeholder="Your Email Address"
                                    onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '"
                                    required="" type="email">
                                <button class="click-btn btn btn-default text-uppercase"> <i class="far fa-paper-plane"></i>
                                </button>
                                <div style="position: absolute; left: -5000px;">
                                    <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value=""
                                        type="text">
                                </div>

                                <div class="info"></div>
                            </form>
                        </div>
                        <p>Subscribe our newsletter to get update news and offers</p>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="single-footer-widget footer_icon">
                        <h4>Kontak</h4>
                        <p></p>
                        <span>php2d.ik.iisbud.sarea@gmail.com</span>
                        <div class="social-icons">
                        <a href="https://www.facebook.com/groups/362178525467199/?ref=share" target="blank"><i class="flaticon-facebook"></i></a>
                            <a href="https://youtube.com/channel/UCaghGJEZsQwnxtPW6UCGjbQ" target="blank"><i class="fab fa-youtube" ></i></a>
                            <a href="https://www.instagram.com/php2d.ijk.iisbudsarea?r=nametag" target="blank"><i class="flaticon-instagram"></i></a>
                           </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="copyright_part_text text-center">
                        <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer part end-->

    <!-- jquery plugins here-->
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

    <script src="<?= base_url() ?>assets/depen/thema/js/jquery-1.12.1.min.js"></script>
    <!-- popper js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/bootstrap.min.js"></script>
    <!-- magnific js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/jquery.magnific-popup.js"></script>
    <!-- swiper js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/owl.carousel.min.js"></script>
    <!-- masonry js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/masonry.pkgd.js"></script>
    <!-- masonry js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/jquery.nice-select.min.js"></script>
    <script src="<?= base_url() ?>assets/depen/thema/js/gijgo.min.js"></script>
    <!-- contact js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/jquery.ajaxchimp.min.js"></script>
    <script src="<?= base_url() ?>assets/depen/thema/js/jquery.form.js"></script>
    <script src="<?= base_url() ?>assets/depen/thema/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>assets/depen/thema/js/mail-script.js"></script>
    <script src="<?= base_url() ?>assets/depen/thema/js/contact.js"></script>
    <!-- custom js -->
    <script src="<?= base_url() ?>assets/depen/thema/js/custom.js"></script>
</body>

</html>